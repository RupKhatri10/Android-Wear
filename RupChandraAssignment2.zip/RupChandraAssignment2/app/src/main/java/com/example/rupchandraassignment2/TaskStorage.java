package com.example.rupchandraassignment2;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Map;

public class TaskStorage {
    private static final String PREFS_NAME = "TaskStorage";

    public static void saveTask(Context context, Task task) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(task.getId(), task.getName() + "|" + task.getDueDateTime());
        editor.apply();
    }

    public static ArrayList<Task> getAllTasks(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Map<String, ?> allEntries = prefs.getAll();
        ArrayList<Task> tasks = new ArrayList<>();

        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            String[] details = entry.getValue().toString().split("\\|");
            tasks.add(new Task(entry.getKey(), details[0], details[1]));
        }
        return tasks;
    }
}
