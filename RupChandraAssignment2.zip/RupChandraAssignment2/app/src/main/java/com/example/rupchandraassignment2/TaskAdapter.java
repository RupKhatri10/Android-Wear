package com.example.rupchandraassignment2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private final List<Task> taskList;

    public TaskAdapter(List<Task> taskList) {
        this.taskList = taskList;
    }

    @Override
    public TaskViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.taskId.setText("ID: " + task.getId());
        holder.taskName.setText("Task: " + task.getName());
        holder.dueDateTime.setText("Due: " + task.getDueDateTime());
    }

    @Override
    public int getItemCount() { return taskList.size(); }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView taskId, taskName, dueDateTime;

        public TaskViewHolder(View itemView) {
            super(itemView);
            taskId = itemView.findViewById(R.id.taskId);
            taskName = itemView.findViewById(R.id.taskName);
            dueDateTime = itemView.findViewById(R.id.dueDateTime);
        }
    }
}
