package com.example.rupchandraassignment2;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ListTaskActivity extends AppCompatActivity {

    private List<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_task);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskList = new ArrayList<>();

        // Load tasks from SharedPreferences
        loadTasks();

        // Pass only taskList to TaskAdapter
        TaskAdapter taskAdapter = new TaskAdapter(taskList);
        recyclerView.setAdapter(taskAdapter);
    }

    private void loadTasks() {
        SharedPreferences sharedPreferences = getSharedPreferences("tasks", MODE_PRIVATE);
        int taskCount = sharedPreferences.getInt("task_count", 0);

        for (int i = 0; i < taskCount; i++) {
            String taskId = sharedPreferences.getString("task_id_" + i, "");
            String taskName = sharedPreferences.getString("task_name_" + i, "");
            String dueDateTime = sharedPreferences.getString("due_date_time_" + i, "");

            Task task = new Task(taskId, taskName, dueDateTime);
            taskList.add(task);
        }
    }
}
