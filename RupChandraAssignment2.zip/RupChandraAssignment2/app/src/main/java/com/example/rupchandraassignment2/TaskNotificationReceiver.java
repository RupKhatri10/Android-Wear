package com.example.rupchandraassignment2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class TaskNotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // Retrieve the task details from the Intent
        String taskId = intent.getStringExtra("taskId");
        String taskName = intent.getStringExtra("taskName");

        // Trigger the notification using the NotificationHelper
        NotificationHelper notificationHelper = new NotificationHelper(context);
        notificationHelper.sendTaskNotification(taskId, taskName);
    }
}
