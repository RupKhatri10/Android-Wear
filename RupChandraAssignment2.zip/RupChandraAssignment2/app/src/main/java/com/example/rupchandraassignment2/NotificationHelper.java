package com.example.rupchandraassignment2;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class NotificationHelper {

    private final Context context;
    private final NotificationManager notificationManager;

    private static final String CHANNEL_ID = "task_notifications";
    private static final String CHANNEL_NAME = "Task Notifications";

    public NotificationHelper(Context context) {
        this.context = context;
        notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void sendTaskNotification(String taskId, String taskName) {
        Intent intent = new Intent(context, ListTaskActivity.class);
        intent.putExtra("taskId", taskId);
        intent.putExtra("taskName", taskName);

        // Create a pending intent that will open ListTaskActivity when clicked
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Create the notification
        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)  // Your app's icon
                .setContentTitle("Task Reminder")
                .setContentText("You have a task: " + taskName)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)  // Automatically removes the notification when clicked
                .build();

        // Show the notification
        notificationManager.notify(Integer.parseInt(taskId), notification);  // Use task ID as notification ID
    }
}
