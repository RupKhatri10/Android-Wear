package com.example.rupchandraassignment2;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public class NotificationActivity extends AppCompatActivity {
    private TextView dueTasksText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        dueTasksText = findViewById(R.id.dueTasksText);
        loadDueTasks();
    }

    private void loadDueTasks() {
        SharedPreferences prefs = getSharedPreferences("TaskStorage", MODE_PRIVATE);
        Map<String, ?> allTasks = prefs.getAll();
        StringBuilder dueTasks = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        long currentTime = System.currentTimeMillis();

        for (Map.Entry<String, ?> entry : allTasks.entrySet()) {
            String[] details = entry.getValue().toString().split("\\|");
            try {
                Date taskDate = sdf.parse(details[1]);
                if (taskDate != null && taskDate.getTime() - currentTime <= 3600000) { // within next hour
                    dueTasks.append("ID: ").append(entry.getKey())
                            .append("\nTask: ").append(details[0])
                            .append("\nDue: ").append(details[1]).append("\n\n");
                }
            } catch (ParseException e) {
//                e.printStackTrace();
                Log.e("NotificationActivity", "Error Occurred", e);
            }
        }

        dueTasksText.setText(dueTasks.length() > 0 ? dueTasks.toString() : "No tasks due in the next hour.");
    }
}
