package com.example.rupchandraassignment2;

public class Task {
    private final String id;
    private final String name;
    private final String dueDateTime;

    public Task(String id, String name, String dueDateTime) {
        this.id = id;
        this.name = name;
        this.dueDateTime = dueDateTime;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDueDateTime() { return dueDateTime; }
}
