package com.example.rupchandraassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAddTask = findViewById(R.id.btnAddTask);
        Button btnListTask = findViewById(R.id.btnListTask);

        btnAddTask.setOnClickListener(v -> startActivity(new Intent(this, AddTaskActivity.class)));
        btnListTask.setOnClickListener(v -> startActivity(new Intent(this, ListTaskActivity.class)));
    }
}
