package com.example.rupchandraassignment2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AddTaskActivity extends AppCompatActivity {

    private EditText editTaskId, editTaskName, editDueDateTime;

    // ActivityResultLauncher to handle result from speech recognition activity
    private final ActivityResultLauncher<Intent> voiceRecognitionLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    ArrayList<String> matches = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if (matches != null && !matches.isEmpty()) {
                        editTaskName.setText(matches.get(0)); // Set the recognized text
                    }
                }
            }
    );


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        editTaskId = findViewById(R.id.editTaskId);
        editTaskName = findViewById(R.id.editTaskName);
        editDueDateTime = findViewById(R.id.editDueDateTime);
        Button btnSelectDateTime = findViewById(R.id.btnSelectDateTime);
        Button btnSaveTask = findViewById(R.id.btnSaveTask);

        // Set input type for task name (text)
        editTaskName.setInputType(InputType.TYPE_CLASS_TEXT);

        // Initialize select date and time button
        btnSelectDateTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add functionality for date and time picker here
                // Example: open DatePicker or TimePicker dialog
            }
        });

        // Initialize Save Task button
        btnSaveTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTask();
            }
        });

        // Initialize Voice Recognition for task name
        editTaskName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startVoiceRecognition();
            }
        });
    }

    private void startVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak the task name");

        voiceRecognitionLauncher.launch(intent); // Use Activity Result API
    }


    private void saveTask() {
        String taskId = editTaskId.getText().toString();
        String taskName = editTaskName.getText().toString();
        String dueDateTime = editDueDateTime.getText().toString();

        if (taskId.isEmpty() || taskName.isEmpty() || dueDateTime.isEmpty()) {
            Toast.makeText(this, "All fields must be filled", Toast.LENGTH_SHORT).show();
        } else {
            // Save the task to SharedPreferences (or another storage solution)
            SharedPreferences sharedPreferences = getSharedPreferences("tasks", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            int taskCount = sharedPreferences.getInt("task_count", 0);

            // Store task details in SharedPreferences
            editor.putString("task_id_" + taskCount, taskId);
            editor.putString("task_name_" + taskCount, taskName);
            editor.putString("due_date_time_" + taskCount, dueDateTime);
            editor.putInt("task_count", taskCount + 1);  // Increment task count
            editor.apply();

            Toast.makeText(this, "Task saved successfully", Toast.LENGTH_SHORT).show();
            finish();  // Close the activity after saving
        }
    }
}
