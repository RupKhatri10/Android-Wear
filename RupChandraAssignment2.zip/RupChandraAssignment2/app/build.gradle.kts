plugins {
    alias(libs.plugins.android.application)
//    id ("com.android.application")
}

android {
    namespace = "com.example.rupchandraassignment2"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.rupchandraassignment2"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {

    implementation(libs.play.services.wearable)
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    implementation("androidx.core:core-ktx:1.12.0") // Updated version
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0") // Updated version
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Wear OS Dependencies
    implementation("androidx.wear:wear:1.3.0") // Updated from 1.2.0
    implementation("androidx.wear:wear-input:1.2.0")
    implementation("androidx.wear:wearable:2.10.0") // Updated from 2.9.0
    implementation("androidx.recyclerview:recyclerview:1.3.1") // Minor update
    implementation("androidx.wear:wear-watchface:1.2.0") // Updated version

    // Voice Input
    implementation("androidx.activity:activity:1.8.0") // Updated from 1.6.1

    // Notification & WorkManager
    implementation("androidx.work:work-runtime:2.9.0") // Updated WorkManager
    implementation("androidx.activity:activity-ktx:1.8.0") // Updated from 1.3.1

    // Optional: Helps handle notification permission on Android 13+
    implementation("androidx.core:core-splashscreen:1.0.1")

    implementation("androidx.core:core-splashscreen:1.0.1")

    // Notification support (including Android 13+)
    implementation("androidx.core:core-notification:1.0.0")
}